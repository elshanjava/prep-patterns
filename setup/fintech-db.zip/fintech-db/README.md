# Fintech SQL Practice DB

Локальная PostgreSQL-база с **реальным объёмом** для тренировки SQL под лайв-кодинг.
Та же fintech-схема, что и в трейнере (`fintech_sql_trainer`), но заполнена сгенерированными данными.

## Что внутри

```
fintech-db/
├── docker-compose.yml
├── migrations/
│   ├── 01_schema.sql   — таблицы + индексы
│   └── 02_seed.sql     — генерация данных (детерминированная)
└── README.md
```

Схема: `users → accounts → transactions / ledger_entries`, плюс `cards`, `jobs`, `payments`.

Объём (детерминированный — у всех одинаковый, seed зафиксирован):

| Таблица         | Строк   |
|-----------------|---------|
| users           | 500     |
| accounts        | ~1000   |
| transactions    | ~63 000 |
| ledger_entries  | ~16 000 |
| cards           | ~400    |
| jobs            | 200     |
| payments        | 50      |

Данные консистентны:
- `accounts.balance` = сумма её `SETTLED`-транзакций;
- `ledger_entries` сбалансированы по двойной записи (Σ DEBIT = Σ CREDIT);
- `users.referred_by` образует реферальное дерево (глубина до ~7) — для рекурсивных CTE;
- есть намеренные дубли транзакций (для задачи «дедуп») и разрывы в датах активности (для gaps-and-islands);
- индексы на `created_at`, `account_id` и т.д. — чтобы `EXPLAIN` показывал реальную разницу Index vs Seq Scan.

## Запуск

```bash
docker compose up -d
```

Миграции применяются автоматически при **первом** старте. Через пару секунд база готова.

Проверить, что поднялось:
```bash
docker compose ps
docker compose logs -f db      # видно, как отработали 01_schema и 02_seed
```

## Подключение

**psql (внутри контейнера):**
```bash
docker exec -it fintech-db psql -U fintech -d fintech
```

**psql / DBeaver / DataGrip (с хоста):**

| Параметр  | Значение   |
|-----------|------------|
| Host      | localhost  |
| Port      | 5432       |
| Database  | fintech    |
| User      | fintech    |
| Password  | fintech    |

```bash
psql "postgresql://fintech:fintech@localhost:5432/fintech"
```

## Пересоздать базу с нуля

Миграции в `/docker-entrypoint-initdb.d` выполняются только когда том пустой.
Чтобы перезалить (например, после правки сида):

```bash
docker compose down -v      # -v удаляет том с данными
docker compose up -d        # миграции прогонятся заново
```

## Как тренироваться

1. Держи рядом справочник `fintech_sql_trainer.docx` — там 30 задач по слоям.
2. В трейнере примеры используют id из маленького сида (`account_id=101`, `id=1004`).
   В этой большой базе id другие: **счета начинаются с 1001**, транзакции с 1.
   Бери реальный счёт, например:
   ```sql
   SELECT id FROM accounts WHERE status='ACTIVE' LIMIT 1;   -- напр. 1001
   ```
   и подставляй его в оконные/gaps-and-islands задачи.
3. Тренируй на объёме то, что на маленьком сиде не прочувствовать:
   - `EXPLAIN (ANALYZE, BUFFERS)` — реальные планы, Index vs Seq Scan, стоимость сортировок;
   - keyset-пагинация по 63k строк vs `OFFSET`;
   - оконные функции и `NTILE` на распределении из сотен счетов;
   - gaps-and-islands по настоящим разрывам активности.

## Быстрый smoke-test

```sql
-- топ-5 счетов по обороту
SELECT account_id, SUM(ABS(amount)) AS turnover
FROM transactions
GROUP BY account_id
ORDER BY turnover DESC
LIMIT 5;
```
